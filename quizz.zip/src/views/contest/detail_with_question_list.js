import React, {Component} from 'react'
import {
    TheFooter,
    TheHeaderInner
} from '../../containers/index'
import {ToastContainer, toast} from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import languages from '../../languages';
import configuration from '../../config';
import {reactLocalStorage} from 'reactjs-localstorage';
import {
    CModal,
    CModalBody,
  } from '@coreui/react';
import $ from 'jquery';
let contestId,roundId;
class DetailContestWithQuestionList extends Component {
	constructor(props) {
        super(props);
        this.state = {
        	contestData:{},
        	roundData:{},
        	listArr:[],
        	selectedAnswer:[],
        	indexQuestion:0,
			gameId:''
		};
	}

	componentDidMount(){

		var url = window.location.href;

		var urlParts =url.substring(url.lastIndexOf('/') + 1);
        urlParts = urlParts.split('?');

        if (urlParts[1]) {
        	roundId = urlParts[1];
        }
        if (urlParts[0]) {
        	contestId = urlParts[0];

			fetch(configuration.baseURL+"contest/contest?contestId="+contestId, {
	                method: "GET",
	                headers: {
	                    'Accept': 'application/json',
	                    'Content-Type': 'application/json',
	                    'Authorization': 'Bearer ' + reactLocalStorage.get('clientToken'),
	                }
	            }).then((response) =>{
		    	return response.json();
		    }).then((data)=> {
		    	if (data.data.length > 0) {
			   		this.setState({contestData:data.data[0]});
			   	}
			});	
        }
        if (contestId && roundId) {

        	fetch(configuration.baseURL+"round/round?roundId="+roundId, {
	                method: "GET",
	                headers: {
	                    'Accept': 'application/json',
	                    'Content-Type': 'application/json',
	                    'Authorization': 'Bearer ' + reactLocalStorage.get('clientToken'),
	                }
	            }).then((response) =>{
		    	return response.json();
		    }).then((data)=> {				
				if (data.data.length > 0) {
	   				var data = data.data;
		   			this.setState({roundData:data[0]});
	   			}
	   			else
	   			{
		   			this.setState({roundData:{}});
	   			}
			});	


			var postData = {};
	    	postData.contestId=contestId;
	    	postData.roundId=roundId;
	    	postData.createdBy=JSON.parse(reactLocalStorage.get('userData')).userId;
	    	// console.log(postData);
	        fetch(configuration.APIbaseURL+"game/game", {
	            method: "post",
	            headers: {
					'Accept': 'application/json',
					'Content-Type': 'application/json',
	                'Authorization': 'Bearer ' + reactLocalStorage.get('clientToken'),
	            },
	            body:JSON.stringify(postData)
	        }).then((response) => {
	            return response.json();
	        }).then((data) => {
	            if(data.code === 200){
	            	  this.setState({gameId:data.data._id})
	            }
	            else
	            {
	                return toast.error(data.message);
	            }
	        });  

			this.getList(roundId);
		}
	}

	saveExitAnswer(){

	}

	saveIndexAnswer(){
		var temp = false;
		for (var i = 0; i < this.state.listArr[this.state.indexQuestion]['answers'].length; i++) {
			console.log(this.state.listArr[this.state.indexQuestion]['selectAnswer'].includes(this.state.listArr[this.state.indexQuestion]['answers'][i].answer) && this.state.listArr[this.state.indexQuestion]['answers'][i].correctAnswer === true);
			if(this.state.listArr[this.state.indexQuestion]['selectAnswer'].includes(this.state.listArr[this.state.indexQuestion]['answers'][i].answer) && this.state.listArr[this.state.indexQuestion]['answers'][i].correctAnswer === true){
				temp = true;
				break;
			}
		}

		if (temp) {
			let fields = this.state.listArr;
			fields[this.state.indexQuestion]['isAnswerTrue'] = true; 
			this.setState({listArr:fields});
		}

		if (this.state.indexQuestion < this.state.listArr.length && this.state.listArr[this.state.indexQuestion]['answerType'] === 2) {
    		this.setState({indexQuestion:this.state.indexQuestion+1})
    	}
    	else
    	{
    		this.saveExitAnswer();	
    	}
		
	}	

	handleSingleSelectChange(index,e){
		let fields = this.state.listArr;
		fields[index]['selectAnswer'] = e.answer; 
    	fields[index]['isAnswerTrue'] = e.correctAnswer; 
    	
    	this.setState({listArr:fields});

    	if (index < this.state.listArr.length) {
    		this.setState({indexQuestion:index+1})
    	}
    	else
    	{
    		this.saveExitAnswer();	
    	}

        
	}



	handleMultiSelectChange(index,e){
		let fields = this.state.listArr;

		if(Array.isArray(fields[index]['selectAnswer'])) {
			if (fields[index]['selectAnswer'].includes(e.answer)) {
				var arrindex = fields[index]['selectAnswer'].indexOf(e.answer);
			    if (arrindex > -1) {
			        fields[index]['selectAnswer'].splice(arrindex, 1);
			    }
			}
			else
			{
				fields[index]['selectAnswer'].push(e.answer);
			}
		}
		else
		{
			fields[index]['selectAnswer'] = [];
			fields[index]['selectAnswer'].push(e.answer);
		}

    	this.setState({listArr:fields});
       
	}



	handleChange(index,correctAnswer='',e){
		let fields = this.state.listArr;
        if (this.state.listArr.length === index) {
        	this.saveExitAnswer();
        }
        else
        {
        }

        console.log(fields[index])
       
	}
	getList(roundId1)
	{
		fetch(configuration.baseURL+"roundQuestion/roundQuestion?roundId="+roundId1, {
                method: "GET",
                headers: {
                    'Accept': 'application/json',
                    'Content-Type': 'application/json',
                    'Authorization': 'Bearer ' + reactLocalStorage.get('clientToken'),
                }
            }).then((response) =>{
	    	return response.json();
	    }).then((data)=> {
			var data = data.data;
	   		this.setState({listArr:data});
		});	
	}


	render() {
		return (
			<>
				<TheHeaderInner />		
				<ToastContainer position="top-right" autoClose={10000} style={{top:'80px'}}/>		
					<main id="main">
		            <section id="hero" class="d-flex align-items-center width75">
		                <div class="quizz-game">
		                    <h3>{this.state.contestData.title}</h3>
		                    <p>{this.state.roundData.gameType}</p>
		                    <div class="quizz-quas">
		                        <h4>Question {this.state.indexQuestion+1}/{this.state.listArr.length}</h4>


		                        {
		                        	this.state.listArr.map((e, key) => {
		                        		let classname = (key === this.state.indexQuestion) ? "step_progress yellow_" : 
		                        		(e.selectAnswer) ? ((e.isAnswerTrue) ? "step_progress blue_" : "step_progress pink_") : "step_progress";
                                        return <div className={classname}></div>
                                    })
		                        }		                        
		                        <div id="app"></div>
		                    </div>   
		                    { (this.state.listArr[this.state.indexQuestion]) ? 
			                    <div class="qus">
			                        <h3>{this.state.listArr[this.state.indexQuestion]['question']}</h3>

			                        <div class="answer-option">

			                        	{
			                        		(this.state.listArr[this.state.indexQuestion]['answerType'] === 1) ? 

			                        			this.state.listArr[this.state.indexQuestion]['answers'].map((e, key) => {
			                        				var forclass=e._id+key;
		                                            return <p class={
		                                            		(this.state.listArr[this.state.indexQuestion]['selectAnswer']) ? 
		                                            		(this.state.listArr[this.state.indexQuestion]['selectAnswer'] === e.answer && e.correctAnswer === true) ? 
		                                            			'fancy2 highlight' : 
	                                            				(this.state.listArr[this.state.indexQuestion]['selectAnswer'] === e.answer && e.correctAnswer === false) ? 'fancy2 pinkhighlight' : 'fancy2' 
	                                            				: 'fancy2'
	                                            			}>
							                                <label >
							                                    
					                                    		{(key === 0) ? <b class="option_ _a">A</b> : null}
					                                    		{(key === 1) ? <b class="option_ _b">B</b> : null}
					                                    		{(key === 2) ? <b class="option_ _c">C</b> : null}
					                                    		{(key === 3) ? <b class="option_ _d">D</b> : null}
					                                    		{(key === 4) ? <b class="option_ _e">E</b> : null}
					                                    		{(key === 5) ? <b class="option_ _f">F</b> : null}
							                                    
							                                    {(this.state.listArr[this.state.indexQuestion]['selectAnswer'] === e.answer && e.correctAnswer === true) ? 
							                                    	<input id={forclass} name={this.state.listArr[this.state.indexQuestion]['_id']} type="radio" onChange={this.handleSingleSelectChange.bind(this,this.state.indexQuestion,e)} value={e.answer} checked="checked"/> : 
							                                    	<input id={forclass} name={this.state.listArr[this.state.indexQuestion]['_id']} type="radio" onChange={this.handleSingleSelectChange.bind(this,this.state.indexQuestion,e)} value={e.answer}  />
							                                    }							                                    
							                                    <span for={forclass}>{e.answer}</span>
							                                </label>
							                            </p>
	                                        	})

			                        		: null
			                        	}

			                        	{
			                        		(this.state.listArr[this.state.indexQuestion]['answerType'] === 2) ? 
			                        		<div>
			                        		{
				                        		this.state.listArr[this.state.indexQuestion]['answers'].map((e, key) => {
				                        				var forclass=e._id+key;
				                        				// var pcalss = (this.state.listArr[this.state.indexQuestion]['selectAnswer']) ? 
				                             //                		(this.state.listArr[this.state.indexQuestion]['selectAnswer'].includes(e.answer) && e.correctAnswer === true) ? 
				                             //                			'fancy2 highlight' : 
			                              //               				(this.state.listArr[this.state.indexQuestion]['selectAnswer'] && this.state.listArr[this.state.indexQuestion]['selectAnswer'].includes(e.answer) && e.correctAnswer === false) ? 'fancy2 pinkhighlight' : 'fancy2' 
			                              //               				: 'fancy2';
			                            var pcalss = (key === 0) ? 
			                            ((this.state.listArr[this.state.indexQuestion]['selectAnswer']) ? "fancy2 fancy2_a" : "fancy2") : "fancy2";
			                            var pcalss = (key === 1) ? 
			                            ((this.state.listArr[this.state.indexQuestion]['selectAnswer']) ? "fancy2 fancy2_b" : "fancy2") : "fancy2";
			                            var pcalss = (key === 2) ? 
			                            ((this.state.listArr[this.state.indexQuestion]['selectAnswer']) ? "fancy2 fancy2_c" : "fancy2") : "fancy2";
			                            var pcalss = (key === 3) ? 
			                            ((this.state.listArr[this.state.indexQuestion]['selectAnswer']) ? "fancy2 fancy2_d" : "fancy2") : "fancy2";
			                            var pcalss = (key === 4) ? 
			                            ((this.state.listArr[this.state.indexQuestion]['selectAnswer']) ? "fancy2 fancy2_e" : "fancy2") : "fancy2";
			                            var pcalss = (key === 5) ? 
			                            ((this.state.listArr[this.state.indexQuestion]['selectAnswer']) ? "fancy2 fancy2_f" : "fancy2") : "fancy2";
			                                            return <p class={pcalss}>
								                                <label >
								                                    
						                                    		{(key === 0) ? <b class="option_ _a">A</b> : null}
						                                    		{(key === 1) ? <b class="option_ _b">B</b> : null}
						                                    		{(key === 2) ? <b class="option_ _c">C</b> : null}
						                                    		{(key === 3) ? <b class="option_ _d">D</b> : null}
						                                    		{(key === 4) ? <b class="option_ _e">E</b> : null}
						                                    		{(key === 5) ? <b class="option_ _f">F</b> : null}
							                                    
								                                    {(this.state.listArr[this.state.indexQuestion]['selectAnswer'] && this.state.listArr[this.state.indexQuestion]['selectAnswer'].includes(e.answer) && e.correctAnswer === true) ? 
								                                    	<input id={forclass} name={this.state.listArr[this.state.indexQuestion]['_id']} type="checkbox" onChange={this.handleMultiSelectChange.bind(this,this.state.indexQuestion,e)} value={e.answer} checked="checked"/> : 
								                                    	<input id={forclass} name={this.state.listArr[this.state.indexQuestion]['_id']} type="checkbox" onChange={this.handleMultiSelectChange.bind(this,this.state.indexQuestion,e)} value={e.answer}  />
								                                    }							                                    
								                                    <span for={forclass}>{e.answer}</span>
								                                </label>
								                            </p>
		                                        	})
				                        	}
			                        		<div class="align-self-center">
			                                	<button style={{minWidth: '150px'}} class="pink_btn" type="button" onClick={this.saveIndexAnswer.bind(this)}>Save</button>
			                                </div>
			                                </div>

			                        		: null
			                        	}

			                        	{
			                        		(this.state.listArr[this.state.indexQuestion]['answerType'] === 3) ? 
			                        		this.state.listArr[this.state.indexQuestion]['answers'].map((e, key) => {
			                        				var forclass=e._id+key;
		                                            return <p class={
		                                            		(this.state.listArr[this.state.indexQuestion]['selectAnswer']) ? 
		                                            		(this.state.listArr[this.state.indexQuestion]['selectAnswer'] === e.answer && e.correctAnswer === true) ? 
		                                            			'fancy2 highlight' : 
	                                            				(this.state.listArr[this.state.indexQuestion]['selectAnswer'] === e.answer && e.correctAnswer === false) ? 'fancy2 pinkhighlight' : 'fancy2' 
	                                            				: 'fancy2'
	                                            			}>
							                                <label >
							                                    {/*<b class="option_">A</b>*/}
							                                    {(this.state.listArr[this.state.indexQuestion]['selectAnswer'] === e.answer && e.correctAnswer === true) ? 
							                                    	<input id={forclass} name={this.state.listArr[this.state.indexQuestion]['_id']} type="radio" onChange={this.handleChange.bind(this,this.state.indexQuestion)} value={e.answer} checked="checked"/> : 
							                                    	<input id={forclass} name={this.state.listArr[this.state.indexQuestion]['_id']} type="radio" onChange={this.handleChange.bind(this,this.state.indexQuestion)} value={e.answer}  />
							                                    }							                                    
							                                    <span for={forclass}>{e.answer}</span>
							                                </label>
							                            </p>
	                                        	})
	                                        	 : null
			                        	}

			                        	{
			                        		(this.state.listArr[this.state.indexQuestion]['answerType'] === 4) ? 
			                        		this.state.listArr[this.state.indexQuestion]['answers'].map((e, key) => {
			                        				var forclass=e._id+key;
		                                            return <p class={
		                                            		(this.state.listArr[this.state.indexQuestion]['selectAnswer']) ? 
		                                            		(this.state.listArr[this.state.indexQuestion]['selectAnswer'] === e.answer && e.correctAnswer === true) ? 
		                                            			'fancy2 highlight' : 
	                                            				(this.state.listArr[this.state.indexQuestion]['selectAnswer'] === e.answer && e.correctAnswer === false) ? 'fancy2 pinkhighlight' : 'fancy2' 
	                                            				: 'fancy2'
	                                            			}>
							                                <label >
							                                    {/*<b class="option_">A</b>*/}
							                                    {(this.state.listArr[this.state.indexQuestion]['selectAnswer'] === e.answer && e.correctAnswer === true) ? 
							                                    	<input id={forclass} name={this.state.listArr[this.state.indexQuestion]['_id']} type="radio" onChange={this.handleChange.bind(this,this.state.indexQuestion)} value={e.answer} checked="checked"/> : 
							                                    	<input id={forclass} name={this.state.listArr[this.state.indexQuestion]['_id']} type="radio" onChange={this.handleChange.bind(this,this.state.indexQuestion)} value={e.answer}  />
							                                    }							                                    
							                                    <span for={forclass}>{e.answer}</span>
							                                </label>
							                            </p>
	                                        	})
			                        		: null
			                        	}

			                        	{
			                        		(this.state.listArr[this.state.indexQuestion]['answerType'] === 5) ? 
			                        		this.state.listArr[this.state.indexQuestion]['answers'].map((e, key) => {
			                        				var forclass=e._id+key;
		                                            return <p class="fancy2">
							                                <label >
							                                    {/*<b class="option_">A</b>*/}
							                                    <input id={forclass} name="yaybox" type="radio" value={e.answer} />
							                                    <span for={forclass}>{e.answer}</span>
							                                </label>
							                            </p>
	                                        	})
			                        		: null
			                        	}			                            

			                        </div>

			                        <div class="align-self-center">
	                                	<button style={{minWidth: '150px'}} class="pink_btn" type="button" onClick={this.saveExitAnswer.bind(this)}>Exit</button>
	                                </div>
			                    </div> :null 
		                	}
		                </div>
		            </section>
		            
		  

		        </main>
		    </>
		)
	}
}

export default DetailContestWithQuestionList
