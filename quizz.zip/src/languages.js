export default {
    "languages": [
        {
          "name": "English"
        },
        {
          "name": "Hindi"
        },
        {
          "name": "Gujarati"
        },
        {
          "name": "Marathi"
        },
        {
          "name": "Tamil"
        },
        {
          "name": "Punjabi"
        },
        {
          "name": "Spanish"
        },
        {
          "name": "Bhojpuri"
        },
        {
          "name": "Telugu"
        },
        {
          "name": "Other"
        }
    ]
};