import React from 'react'

const TheSidebar = () => {
  return ('')
}

export default React.memo(TheSidebar)
