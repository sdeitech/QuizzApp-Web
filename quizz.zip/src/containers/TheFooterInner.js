import React from 'react'

const TheFooterInner = () => {
    return (
        <div className="row">
            <div className="col-md-12">
                <div style={{paddingTop: '40px'}} className="footer_link">
                    <p>Copyright 2020. All rights reserved.</p>
                </div>
            </div>
        </div>
    )
}

export default TheFooterInner
